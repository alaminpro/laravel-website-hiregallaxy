<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use App\Models\Skill;
class Answers extends Model
{
    protected $table = 'lar_answer';
}
