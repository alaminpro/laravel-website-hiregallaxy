<?php

return [

    'asset_version' => env('ASSET_VERSION'),

];
