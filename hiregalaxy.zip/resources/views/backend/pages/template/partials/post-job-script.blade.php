<script src="https://cdn.ckeditor.com/4.12.1/standard/ckeditor.js"></script>
<style>
  .cke_editable {
    border: 1px solid #ced4da;
    padding: 10px;
  }

  .cke_editable:focus {
    outline: #607d8b1f auto 1px;
  }
</style>
<script>
  CKEDITOR.inline('job_summery');
  CKEDITOR.inline('responsibilities');
  CKEDITOR.inline('qualification');
  CKEDITOR.inline('certification');
  CKEDITOR.inline('experience');
  CKEDITOR.inline('about_company');
</script>