@extends('frontend.layouts.master')



@section('title')

About Us | HomePage

@endsection



@section('content')



<section class="sec-pad">

	<div class="container">

		<div>

		    {!! $about !!}

		</div>

	</div>

</section>



@endsection



